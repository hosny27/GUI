import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * GUIExploration.java
 * ---------------------------------------------------------------------------
 * Self Exercise / Exploration of Graphical User Interface in Java (Swing)
 * Course : Pemrograman Berorientasi Objek (Object Oriented Programming)
 * Section: PBO-11 - Graphical User Interface (GUI) - Event Listener
 *
 * This single program is an example of the 5 GUI Components/Parts:
 *
 *   1. Top Level Container Class
 *        -> JFrame (the main window of this program)
 *
 *   2. Intermediate Container Class
 *        -> JPanel, JScrollPane
 *
 *   3. Atomic Component Class
 *        -> JLabel, JTextField, JComboBox, JRadioButton, JCheckBox,
 *           JTextArea, JButton
 *
 *   4. Layout Classes (minimum 2, this program uses 3)
 *        -> BorderLayout, FlowLayout, GridLayout
 *
 *   5. Event Listener
 *        -> ActionListener (interface override), KeyAdapter, MouseAdapter,
 *           WindowAdapter (adapter classes)
 * ---------------------------------------------------------------------------
 */
public class GUIExploration extends JFrame {

    // المكونات التي تحتاج الدوال المستمعة (Listeners) للوصول إليها
    // لذلك تم تعريفها هنا كمتغيرات على مستوى الكلاس كله
    private JTextField nameField;
    private JTextField nimField;
    private JComboBox<String> classCombo;
    private JRadioButton maleRadio;
    private JRadioButton femaleRadio;
    private JCheckBox readingCheck;
    private JCheckBox sportsCheck;
    private JCheckBox musicCheck;
    private JTextArea notesArea;
    private JLabel statusLabel;
    private JLabel charLabel;

    /**
     * الدالة البنّاءة (Constructor):
     * تُستدعى مرة واحدة عند إنشاء النافذة، وفيها يتم بناء الواجهة الرسومية
     * بالكامل: إعداد النافذة الرئيسية، إنشاء الحاويات والمكونات، ترتيبها
     * بمديري التخطيط، ثم ربط مستمعات الأحداث بالمكونات.
     */
    public GUIExploration() {

        // ==================================================================
        // 1. TOP LEVEL CONTAINER CLASS : JFrame
        //    هذا الكلاس يرث من JFrame، وهو الحاوية العليا التي تحتوي
        //    على كل مكونات البرنامج الأخرى.
        // ==================================================================
        setTitle("GUI Exploration - Student Data Form"); // عنوان النافذة
        setSize(560, 540);                               // أبعاد النافذة
        setLocationRelativeTo(null);                     // توسيط النافذة على الشاشة
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);   // الإغلاق يُعالج يدويًا بالأسفل

        // ==================================================================
        // 4. LAYOUT CLASSES (1 من 3) : BorderLayout للنافذة الرئيسية
        // ==================================================================
        setLayout(new BorderLayout(8, 8));

        // ==================================================================
        // 2. INTERMEDIATE CONTAINER CLASS : JPanel (لوحة العنوان)
        // 4. LAYOUT CLASSES (2 من 3) : FlowLayout للوحة العنوان
        // 3. ATOMIC COMPONENT CLASS : JLabel
        // ==================================================================
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel titleLabel = new JLabel("Student Data Form");
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        headerPanel.add(titleLabel);
        add(headerPanel, BorderLayout.NORTH);

        // ==================================================================
        // 2. INTERMEDIATE CONTAINER CLASS : JPanel (لوحة النموذج)
        // 4. LAYOUT CLASSES (3 من 3) : GridLayout للوحة النموذج
        // 3. ATOMIC COMPONENT CLASS : JTextField, JComboBox, JRadioButton,
        //    JCheckBox (داخل لوحات أصغر بتخطيط FlowLayout)
        // ==================================================================
        JPanel formPanel = new JPanel(new GridLayout(5, 2, 8, 8));
        formPanel.setBorder(BorderFactory.createEmptyBorder(4, 12, 4, 12));

        // الصف الأول: الاسم (حقل نصي JTextField)
        formPanel.add(new JLabel("Name :"));
        nameField = new JTextField();
        formPanel.add(nameField);

        // الصف الثاني: الرقم الجامعي NIM (حقل نصي JTextField)
        formPanel.add(new JLabel("NIM :"));
        nimField = new JTextField();
        formPanel.add(nimField);

        // الصف الثالث: الفصل (قائمة منسدلة JComboBox)
        formPanel.add(new JLabel("Class :"));
        classCombo = new JComboBox<>(new String[]{"5A", "5B", "5C", "5D"});
        formPanel.add(classCombo);

        // الصف الرابع: النوع (أزرار اختيار JRadioButton داخل لوحة FlowLayout)
        // ملحوظة: ButtonGroup تجعل اختيار أحد الزرين يلغي الآخر تلقائيًا
        formPanel.add(new JLabel("Gender :"));
        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        maleRadio = new JRadioButton("Male", true);
        femaleRadio = new JRadioButton("Female");
        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(maleRadio);
        genderGroup.add(femaleRadio);
        genderPanel.add(maleRadio);
        genderPanel.add(femaleRadio);
        formPanel.add(genderPanel);

        // الصف الخامس: الهوايات (خانات اختيار JCheckBox داخل لوحة FlowLayout)
        // يمكن اختيار أكثر من هواية في نفس الوقت
        formPanel.add(new JLabel("Hobbies :"));
        JPanel hobbyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        readingCheck = new JCheckBox("Reading");
        sportsCheck = new JCheckBox("Sports");
        musicCheck = new JCheckBox("Music");
        hobbyPanel.add(readingCheck);
        hobbyPanel.add(sportsCheck);
        hobbyPanel.add(musicCheck);
        formPanel.add(hobbyPanel);

        // ==================================================================
        // 2. INTERMEDIATE CONTAINER CLASS : JScrollPane حول منطقة النص
        //    وظيفته إضافة أشرطة تمرير لمنطقة الملاحظات عند امتلائها
        // 3. ATOMIC COMPONENT CLASS : JTextArea
        // ==================================================================
        JPanel notesPanel = new JPanel(new BorderLayout(4, 4));
        notesPanel.setBorder(BorderFactory.createEmptyBorder(4, 12, 4, 12));
        notesPanel.add(new JLabel("Notes :"), BorderLayout.NORTH);
        notesArea = new JTextArea(5, 30);
        notesArea.setLineWrap(true);        // التفاف النص عند نهاية السطر
        notesArea.setWrapStyleWord(true);   // الالتفاف عند حدود الكلمات
        JScrollPane scrollPane = new JScrollPane(notesArea); // حاوية وسيطة للتمرير
        notesPanel.add(scrollPane, BorderLayout.CENTER);

        // لوحة وسيطة تجمع النموذج في الأعلى والملاحظات في الأسفل
        JPanel centerPanel = new JPanel(new BorderLayout(4, 4));
        centerPanel.add(formPanel, BorderLayout.NORTH);
        centerPanel.add(notesPanel, BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);

        // ==================================================================
        // 3. ATOMIC COMPONENT CLASS : JButton (أزرار الأوامر)
        // 2. INTERMEDIATE CONTAINER CLASS : JPanel (لوحتا الأزرار والحالة)
        // ==================================================================
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 6));
        JButton submitButton = new JButton("Submit");
        JButton clearButton = new JButton("Clear");
        JButton exitButton = new JButton("Exit");
        buttonPanel.add(submitButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(exitButton);

        // شريط الحالة أسفل النافذة: رسالة الحالة يسارًا وعدّاد الحروف يمينًا
        JPanel statusPanel = new JPanel(new BorderLayout());
        statusPanel.setBorder(BorderFactory.createEmptyBorder(2, 12, 6, 12));
        statusLabel = new JLabel("Ready.");
        charLabel = new JLabel("Name characters: 0");
        statusPanel.add(statusLabel, BorderLayout.WEST);
        statusPanel.add(charLabel, BorderLayout.EAST);

        JPanel southPanel = new JPanel(new BorderLayout());
        southPanel.add(buttonPanel, BorderLayout.CENTER);
        southPanel.add(statusPanel, BorderLayout.SOUTH);
        add(southPanel, BorderLayout.SOUTH);

        // ==================================================================
        // 5. EVENT LISTENER : مستمعات الأحداث
        // ==================================================================

        // --- 5أ. ActionListener : واجهة مستمع (Interface).
        //     الدالة actionPerformed() التالية هي Override لدالة الواجهة،
        //     وتُنفَّذ تلقائيًا عند الضغط على زر Submit.
        //     وظيفتها: جمع كل البيانات المدخلة في النموذج وعرضها في
        //     نافذة رسالة، وتحديث شريط الحالة باسم الطالب.
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String gender = maleRadio.isSelected() ? "Male" : "Female";

                // تجميع الهوايات المختارة في نص واحد
                StringBuilder hobbies = new StringBuilder();
                if (readingCheck.isSelected()) hobbies.append("Reading ");
                if (sportsCheck.isSelected()) hobbies.append("Sports ");
                if (musicCheck.isSelected()) hobbies.append("Music ");
                String hobbyText = hobbies.length() == 0 ? "-" : hobbies.toString().trim();

                // ترتيب البيانات كلها في رسالة واحدة متعددة الأسطر
                String message = "Name  : " + nameField.getText()
                        + "\nNIM    : " + nimField.getText()
                        + "\nClass  : " + classCombo.getSelectedItem()
                        + "\nGender : " + gender
                        + "\nHobbies: " + hobbyText
                        + "\nNotes  : " + notesArea.getText();

                JOptionPane.showMessageDialog(GUIExploration.this, message,
                        "Submitted Data", JOptionPane.INFORMATION_MESSAGE);
                statusLabel.setText("Data submitted for: " + nameField.getText());
            }
        });

        // --- 5أ (تكملة). ActionListener لزر Clear:
        //     تُنفَّذ عند الضغط على زر Clear، ووظيفتها إعادة كل حقول
        //     النموذج إلى قيمها الافتراضية (مسح النصوص وإلغاء الاختيارات).
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                nameField.setText("");
                nimField.setText("");
                classCombo.setSelectedIndex(0);
                maleRadio.setSelected(true);
                readingCheck.setSelected(false);
                sportsCheck.setSelected(false);
                musicCheck.setSelected(false);
                notesArea.setText("");
                charLabel.setText("Name characters: 0");
                statusLabel.setText("Form cleared.");
            }
        });

        // --- 5أ (تكملة). ActionListener لزر Exit:
        //     تُنفَّذ عند الضغط على زر Exit، ووظيفتها استدعاء دالة
        //     الإغلاق التي تطلب تأكيد المستخدم قبل إنهاء البرنامج.
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                closeWindow();
            }
        });

        // --- 5ب. KeyAdapter : كلاس موائم (Adapter Class) لأحداث لوحة المفاتيح.
        //     الدالة keyReleased() التالية هي Override، وتُنفَّذ كلما رُفع
        //     الإصبع عن أي مفتاح داخل حقل الاسم.
        //     وظيفتها: عدّ حروف الاسم المكتوبة لحظيًا وعرض العدد في
        //     عدّاد الحروف أسفل يمين النافذة.
        nameField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                charLabel.setText("Name characters: " + nameField.getText().length());
            }
        });

        // --- 5ج. MouseAdapter : كلاس موائم (Adapter Class) لأحداث الفأرة.
        //     الدالتان mouseEntered() و mouseExited() هما Override،
        //     وتُنفَّذان عند دخول مؤشر الفأرة إلى زر Submit وخروجه منه.
        //     وظيفتهما: تأثير تمرير (Hover) يلوّن الزر بالأخضر ويعرض
        //     تلميحًا في شريط الحالة، ثم يعيد كل شيء كما كان عند الخروج.
        submitButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                submitButton.setBackground(new Color(180, 220, 180));
                statusLabel.setText("Click Submit to send the form.");
            }

            @Override
            public void mouseExited(MouseEvent e) {
                submitButton.setBackground(null);
                statusLabel.setText("Ready.");
            }
        });

        // --- 5د. WindowAdapter : كلاس موائم (Adapter Class) لأحداث النافذة.
        //     الدالة windowClosing() التالية هي Override، وتُنفَّذ عند
        //     الضغط على زر الإغلاق (X) الخاص بالنافذة.
        //     وظيفتها: تحويل طلب الإغلاق إلى دالة الإغلاق الموحّدة
        //     التي تطلب التأكيد أولًا.
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                closeWindow();
            }
        });
    }

    /**
     * دالة الإغلاق الموحّدة closeWindow():
     * تُستدعى من زر Exit ومن زر إغلاق النافذة (X).
     * وظيفتها: عرض نافذة تأكيد تسأل المستخدم إن كان متأكدًا من الخروج،
     * فإذا اختار Yes يتم إغلاق النافذة وإنهاء البرنامج،
     * وإذا اختار No لا يحدث شيء ويبقى البرنامج مفتوحًا.
     */
    private void closeWindow() {
        int answer = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to exit?",
                "Exit Confirmation", JOptionPane.YES_NO_OPTION);
        if (answer == JOptionPane.YES_OPTION) {
            dispose();
            System.exit(0);
        }
    }

    /**
     * الدالة الرئيسية main():
     * نقطة بداية تشغيل البرنامج.
     * وظيفتها: إنشاء نافذة GUIExploration وإظهارها للمستخدم، وذلك عبر
     * invokeLater حتى يعمل إنشاء الواجهة الرسومية على خيط الأحداث
     * الخاص بـ Swing (Event Dispatch Thread) كما هو موصى به.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new GUIExploration().setVisible(true);
            }
        });
    }
}
