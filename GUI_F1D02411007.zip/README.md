# GUI Exploration — Java Swing

**Name:** DIAEEDIN ABUMATTAR
**NIM:** F1D02411007
**Class:** 5A
**Course:** Pemrograman Berorientasi Objek (Object Oriented Programming)
**Section:** PBO-11 — Graphical User Interface (GUI) — Event Listener
**Task:** Self Exercise / Exploration of Graphical User Interface in Java

## About the program

`GUIExploration.java` is a single-file Java Swing program: a **Student Data
Form** window. The user can type a name and NIM, choose a class, select a
gender, tick hobbies, write notes, and submit the form. Submitting shows all
the entered data in a dialog. The program was built to explore and demonstrate
the **5 GUI Components/Parts** listed below.

## The 5 GUI Components/Parts in this code

| # | Component / Part | Classes used | Where it appears in the program |
|---|---|---|---|
| 1 | **Top Level Container Class** | `JFrame` | The class `GUIExploration extends JFrame` — the main window that holds everything. |
| 2 | **Intermediate Container Class** | `JPanel`, `JScrollPane` | `JPanel` for the header, form, gender, hobby, button and status areas; `JScrollPane` wraps the notes `JTextArea` so it can scroll. |
| 3 | **Atomic Component Class** | `JLabel`, `JTextField`, `JComboBox`, `JRadioButton`, `JCheckBox`, `JTextArea`, `JButton` | Labels and input fields for Name and NIM, the Class drop-down, Male/Female radio buttons, Reading/Sports/Music check boxes, the notes text area, and the Submit / Clear / Exit buttons. |
| 4 | **Layout Classes** (minimum 2 — this program uses 3) | `BorderLayout`, `FlowLayout`, `GridLayout` | `BorderLayout` arranges the main window (header NORTH, form CENTER, buttons SOUTH); `FlowLayout` arranges the header, gender, hobby and button panels; `GridLayout` arranges the form rows in a 5×2 grid. |
| 5 | **Event Listener** | `ActionListener` (interface), `KeyAdapter`, `MouseAdapter`, `WindowAdapter` (adapter classes) | `actionPerformed()` is **overridden** from the `ActionListener` interface for the Submit, Clear and Exit buttons. From the adapter classes: `keyReleased()` (KeyAdapter) counts the characters typed in the Name field live; `mouseEntered()` / `mouseExited()` (MouseAdapter) give the Submit button a hover effect and update the status bar; `windowClosing()` (WindowAdapter) asks for confirmation before the window closes. |

## Interactions you can try

- **Submit** — collects all input and shows it in an information dialog.
- **Clear** — resets every field to its default value.
- **Exit** (or the window's X button) — asks "Are you sure?" before closing.
- **Typing in the Name field** — the "Name characters" counter in the
  bottom-right corner updates on every key release.
- **Hovering over Submit** — the button turns green and the status bar
  (bottom-left) shows a hint.

## How to compile and run

Requires a JDK (version 8 or newer):

```bash
javac -encoding UTF-8 GUIExploration.java
java GUIExploration
```

(The `-encoding UTF-8` flag is needed because the source file contains
Arabic comments explaining each method.)

## Screenshot

![Screenshot of the running program](screenshot.png)
